import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';
export const jobs = sqliteTable('jobs', { id:text('id').primaryKey(), source:text('source').notNull(), title:text('title').notNull(), company:text('company').notNull(), location:text('location').notNull(), url:text('url').notNull(), updated:text('updated'), description:text('description').notNull().default(''), firstSeen:text('first_seen').notNull(), active:integer('active').notNull().default(1) });
export const scans = sqliteTable('scans', { source:text('source').primaryKey(), checked:text('checked').notNull(), success:text('success'), error:text('error'), count:integer('count').notNull().default(0) });
export const control = sqliteTable('control', { id:text('id').primaryKey(), value:text('value').notNull() });
