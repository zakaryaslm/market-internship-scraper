CREATE TABLE `control` (
	`id` text PRIMARY KEY NOT NULL,
	`value` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `jobs` (
	`id` text PRIMARY KEY NOT NULL,
	`source` text NOT NULL,
	`title` text NOT NULL,
	`company` text NOT NULL,
	`location` text NOT NULL,
	`url` text NOT NULL,
	`updated` text,
	`first_seen` text NOT NULL,
	`active` integer DEFAULT 1 NOT NULL
);
--> statement-breakpoint
CREATE TABLE `scans` (
	`source` text PRIMARY KEY NOT NULL,
	`checked` text NOT NULL,
	`success` text,
	`error` text,
	`count` integer DEFAULT 0 NOT NULL
);
