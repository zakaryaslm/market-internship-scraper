import { env } from 'cloudflare:workers';
import { sources, canonicalUrl } from '@/lib/sources';
function db(){ if(!env.DB)throw Error('Stockage indisponible'); return env.DB; }
export async function GET(){ try { const d=db(); const [j,s]=await Promise.all([d.prepare('SELECT * FROM jobs ORDER BY first_seen DESC, title ASC').all(),d.prepare('SELECT * FROM scans').all()]); return Response.json({jobs:j.results,scans:s.results},{headers:{'Cache-Control':'no-store'}}); }catch(e){console.error(e);return Response.json({error:'Les offres ne peuvent pas être chargées. Réessayez.'},{status:503});} }
export async function POST(request:Request){
 if(request.headers.get('origin') && new URL(request.headers.get('origin')!).host!==new URL(request.url).host) return new Response('Forbidden',{status:403});
 try{
 const d=db(), now=new Date().toISOString();
 const lock=await d.prepare("INSERT INTO control (id,value) VALUES ('scan',?) ON CONFLICT(id) DO UPDATE SET value=excluded.value WHERE control.value < ? RETURNING value").bind(now,new Date(Date.now()-240000).toISOString()).all();
 if(!lock.results.length)return Response.json({message:'Une vérification a déjà eu lieu il y a moins de quatre minutes.'});
 const results=await Promise.all(sources.map(async s=>{
 try{
 const response=await fetch(`https://boards-api.greenhouse.io/v1/boards/${s.id}/jobs?content=true`,{signal:AbortSignal.timeout(20000),headers:{Accept:'application/json'}});
 if(!response.ok)throw Error(`Source indisponible (HTTP ${response.status})`);
 const data=await response.json() as {jobs:any[]}; if(!Array.isArray(data.jobs))throw Error('Format de source non reconnu');
 const rows=data.jobs.map(j=>{if(!j.id||!j.title||!j.absolute_url)throw Error('Offre incomplète');return {id:s.id+':'+j.id,title:String(j.title),location:String(j.location?.name||'Non précisée'),url:canonicalUrl(j.absolute_url),updated:j.updated_at||null,description:String(j.content||'').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/<[^>]*>/g,' ').replace(/&nbsp;|&#160;/g,' ').replace(/&amp;/g,'&').replace(/&#39;|&apos;/g,"'").replace(/&quot;/g,'"').replace(/\s+/g,' ').slice(0,24000)};});
 const statements=[d.prepare('UPDATE jobs SET active=0 WHERE source=?').bind(s.id),...rows.map(j=>d.prepare('INSERT INTO jobs (id,source,title,company,location,url,updated,first_seen,description,active) VALUES (?,?,?,?,?,?,?,?,?,1) ON CONFLICT(id) DO UPDATE SET title=excluded.title,location=excluded.location,url=excluded.url,updated=excluded.updated,description=excluded.description,active=1').bind(j.id,s.id,j.title,s.name,j.location,j.url,j.updated,now,j.description))];
 // One transactional batch: never mark an entire board closed after a partial write.
 await d.batch(statements);
 await d.prepare('INSERT INTO scans (source,checked,success,error,count) VALUES (?,?,?,NULL,?) ON CONFLICT(source) DO UPDATE SET checked=excluded.checked,success=excluded.success,error=NULL,count=excluded.count').bind(s.id,now,now,rows.length).run();
 return {source:s.id,ok:true,count:rows.length};
 }catch(e){const message=e instanceof Error?e.message:'Échec de vérification';await d.prepare('INSERT INTO scans (source,checked,error,count) VALUES (?,?,?,0) ON CONFLICT(source) DO UPDATE SET checked=excluded.checked,error=excluded.error').bind(s.id,now,message).run();return {source:s.id,ok:false};}
 }));return Response.json({results});
 }catch(e){console.error(e);return Response.json({error:'La vérification a échoué. Les offres déjà enregistrées sont conservées.'},{status:503});}
}
