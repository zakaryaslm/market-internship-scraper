/** Conservative ranking: unknown dates/locations are reviewable, never invented. */
export const targetCountries = [
 ['FR','France'],['GB','Royaume-Uni'],['LU','Luxembourg'],['BE','Belgique'],['DE','Allemagne'],['CH','Suisse'],['NL','Pays-Bas'],['ES','Espagne'],['PT','Portugal'],['CA','Canada']
] as const;
const normalize=(s:string)=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const geography: [string,RegExp][] = [
 ['FR',/\b(france|paris|puteaux|courbevoie|la defense|montrouge|lyon|lille|nantes|bordeaux|toulouse|marseille|strasbourg|nice|rennes)\b/],
 ['GB',/\b(united kingdom|uk|u\.k\.|great britain|england|scotland|wales|northern ireland|london|londres|edinburgh|glasgow|manchester|birmingham|belfast|bristol|leeds|cambridge|oxford)\b/],
 ['LU',/\b(luxembourg|luxemburg)\b/],['BE',/\b(belgium|belgique|brussels|bruxelles|antwerp|anvers|ghent|gent|liege)\b/],
 ['DE',/\b(germany|deutschland|allemagne|frankfurt|francfort|berlin|munich|munchen|hamburg|dusseldorf|cologne|koln|stuttgart)\b/],
 ['CH',/\b(switzerland|suisse|schweiz|zurich|geneva|geneve|lausanne|basel|bale|zug|bern|berne|lugano)\b/],
 ['NL',/\b(netherlands|pays.bas|nederland|amsterdam|rotterdam|utrecht|the hague|den haag|eindhoven)\b/],
 ['ES',/\b(spain|espagne|espana|madrid|barcelona|barcelone|valencia|bilbao|malaga|sevilla)\b/],
 ['PT',/\b(portugal|lisbon|lisboa|lisbonne|porto)\b/],['CA',/\b(canada|toronto|montreal|vancouver|calgary|ottawa|quebec|edmonton|waterloo|winnipeg)\b/],
 ['OUT',/\b(new york|nyc|hong kong|singapore|singapour|united states|usa|chicago|boston|austin|houston|miami|san francisco|seattle|los angeles|connecticut|stamford|greenwich|australia|sydney|tokyo|japan|china|shanghai|beijing|india|mumbai|bengaluru|brazil|dubai|united arab emirates|dublin|ireland|italy|milan|italia|austria|vienna|poland|warsaw|sweden|stockholm|denmark|copenhagen)\b/]
];
export function countries(location:string){return geography.filter(([,r])=>r.test(normalize(location))).map(([code])=>code);}
export function internship(title:string){return /\b(intern(ship)?s?|stage|stagiaire|off[ -]?cycle|placement|praktikum|praktikant|estagio|practicas|becario|co[ -]?op)\b/i.test(normalize(title));}
export function summer(title:string){return /\b(summer|ete|sommer)\b/i.test(normalize(title));}
export function domain(title:string){const t=normalize(title);if(/\b(senior|vice president|director|head of|lead)\b/.test(t))return 'other';if(/\b(quant\w*|trader|trading|structur\w*|pricing|xva|derivative\w*|market risk|risques? de marche|sales[ &]+trading|global markets|capital markets|equities|fixed income|fx|commodit\w*|portfolio|asset management|gestion d.actifs|investment research|investment analyst|sales)\b/.test(t))return 'core';if(/\b(risk|risque\w*|research|credit|middle office|trade support|valuation|model validation|financial engineer\w*)\b/.test(t))return 'adjacent';return 'other';}
const monthNames=['jan(?:uary|vier)?','feb(?:ruary)?|fevrier','mar(?:ch)?|mars','apr(?:il)?|avril','may|mai','jun(?:e)?|juin','jul(?:y)?|juillet','aug(?:ust)?|aout','sep(?:tember)?|septembre','oct(?:ober|obre)?','nov(?:ember|embre)?','dec(?:ember|embre)?'];
export function startTiming(title:string,description=''){
 const t=normalize(title);const body=normalize(description);
 // Only title dates and clauses explicitly about starting are candidates; never updated_at.
 const explicit=body.match(/\b(?:start(?:ing)?\s*(?:date)?|commenc(?:e|ing)|debut(?: du stage)?|a partir de|starting from|join us (?:in|from))[^.!?;\n]{0,100}/g)||[];
 const snippets=[t,...explicit]; const found:{year:number;month:number;evidence:string}[]=[];
 for(const snippet of snippets){
  monthNames.forEach((name,i)=>{const r=new RegExp('\\b('+name+')\\.?\\s+(?:\\d{1,2}(?:st|nd|rd|th)?[,]?\\s+)?(20\\d{2})\\b','g');for(const m of snippet.matchAll(r))found.push({year:Number(m[2]),month:i+1,evidence:m[0]});});
  for(const m of snippet.matchAll(/\b(20\d{2})-(0[1-9]|1[0-2])(?:-\d{2})?\b/g))found.push({year:Number(m[1]),month:Number(m[2]),evidence:m[0]});
  for(const m of snippet.matchAll(/\b(?:\d{1,2}\/)?(0?[1-9]|1[0-2])\/(20\d{2})\b/g))found.push({year:Number(m[2]),month:Number(m[1]),evidence:m[0]});
 }
 const valid=found.filter(x=>x.year>=2027);
 const selected=valid.find(x=>x.year===2027&&[3,4].includes(x.month))||valid[0]||found[0];
 if(selected){const {year,month,evidence}=selected;return {bucket:year<2027?'past':year===2027&&[3,4].includes(month)?'priority':year===2027&&month<3?'negotiate':'later',label:`${String(month).padStart(2,'0')}/${year}`,evidence};}
 const years=[...t.matchAll(/\b(20\d{2})\b/g)].map(m=>Number(m[1]));
 if(years.length&&years.every(y=>y<2027))return {bucket:'past',label:'Avant 2027',evidence:title};
 return {bucket:'unknown',label:years.includes(2027)?'2027 · mois à vérifier':'Début à vérifier',evidence:''};
}
export type Candidate={title:string;location:string;description?:string;first_seen?:string};
export function matchJob(j:Candidate){const geo=countries(j.location);const timing=startTiming(j.title,j.description);const fit=domain(j.title);const target=geo.some(c=>c!=='OUT');const locationUnknown=geo.length===0;const relevant=internship(j.title)&&fit!=='other'&&timing.bucket!=='past'&&(target||locationUnknown);const score=(fit==='core'?30:0)+(timing.bucket==='priority'?60:timing.bucket==='negotiate'?30:timing.bucket==='unknown'?15:0)+(geo.includes('FR')?10:0)+(summer(j.title)?-20:0);return {geo,timing,fit,target,locationUnknown,relevant,score};}
