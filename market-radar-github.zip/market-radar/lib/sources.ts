export const sources = [
 {id:'flowtraders',name:'Flow Traders'}, {id:'point72',name:'Point72'}, {id:'fiveringsllc',name:'Five Rings'}, {id:'genevatrading',name:'Geneva Trading'}, {id:'drweng',name:'DRW'}, {id:'optiver',name:'Optiver'}, {id:'imc',name:'IMC Trading'}, {id:'janestreet',name:'Jane Street'}
];
export function isIntern(title:string) { return /\b(intern(ship)?s?|stage|stagiaire|placement|working student|off.cycle|summer analyst)\b/i.test(title); }
export function isMarkets(title:string) { return /trad|quant|research|risk|risqu|portfolio|investment|market|structur|sales|securit|pricing|finance|credit|commodit|equity|equities|fixed income|derivative/i.test(title); }
export function canonicalUrl(raw:string) { const u=new URL(raw); if(u.protocol!=='https:') throw Error('Lien invalide'); for(const k of [...u.searchParams.keys()]) if(/^(utm_|gh_src|source$|ref$)/i.test(k))u.searchParams.delete(k); u.hash=''; return u.toString(); }
